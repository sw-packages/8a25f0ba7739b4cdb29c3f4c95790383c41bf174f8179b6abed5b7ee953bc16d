The code in this directory is based on Ulf Adams's work. The upstream for the
code is:

https://github.com/ulfjack/ryu/tree/59661c3/ryu

The code has been adapted by Stephan T. Lavavej of Microsoft for usage in
std::to_chars. This code has been contributed by Microsoft for inclusion in
libc++.

The code in this directory has a different coding style than other parts to
minimize the number of changes by both upstream sources.
